from django.db import models


class Customers(models.Model):
    first_name = models.CharField(max_length=50,default=None)
    last_name = models.CharField(max_length=50,default='')
    phone = models.CharField(max_length=15,default='')
    email = models.EmailField(max_length=50,null=True)
    password = models.CharField(max_length=15,default='')

    def register(self):
        self.save()


    def Isexist(self):
        if Customers.objects.filter(email = self.email):
            return True
        else:
            return False
    @staticmethod
    def loginCheck(email):
        try:
            return Customers.objects.get(email=email)
        except:
            return False
