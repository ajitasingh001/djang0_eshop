from django import template
register = template.Library()

@register.filter(name = 'is_in_cart')
def is_in_cart(product,cart):
    keys=cart.keys()
    for key in keys:
        productid = int(key)
        if product.id == productid:
            return True
    return False

@register.filter(name = 'cart_quantity')
def is_in_cart_quantity(product,cart):
    keys=cart.keys()
    for key in keys:
        productid = int(key)
        if product.id == productid:
            return cart.get(key)

@register.filter(name = 'item_price_total')
def cart_price(product,cart):
    return product.price * is_in_cart_quantity(product,cart)

@register.filter(name = 'cart_total')
def cart_totalprice(product,cart):
    sum=0
    for p in product:
        sum+=cart_price(p,cart)
    return sum

@register.filter(name = 'price_total')
def price_total(price,quantity):
    return price*quantity

