from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.product import Product
from Gshop.models.category import Category
from Gshop.models.customer import Customers
from django.views import View
#Create your views here.


class Index(View):
   def get(self,request):
      cart =request.session.get('cart')
      if not cart:
         request.session['cart'] = {}
      product = None
      category =Category.get_all_categories()
      categoryid = request.GET.get('category')
      data={}
      if categoryid:
         product = Product.get_all_products_by_categoryid(categoryid)
      else :
         product = Product.get_all_products()

      data['product']=product
      data['category'] = category
      print('session data is here .....',request.session.get('email'))
      return render(request,'index.html',data)
   def post(self,request):
      product_id = request.POST.get('product_id')
      cart = request.session.get('cart')
      print('earlier cart....',cart)
      if cart:
         if product_id in cart:
            quantity = cart[product_id]
            if request.POST.get('remove'):
               cart[product_id] = quantity-1
               if quantity <=1:
                  cart.pop(product_id)
            else:
               cart[product_id] = quantity+1
            request.session['cart'] = cart
         else:
            cart[product_id]=1
            request.session['cart'] = cart
      else:
         cart ={}
         cart[product_id]=1
         request.session['cart'] = cart
      print(request.session['cart'])
      return redirect('homepage')





