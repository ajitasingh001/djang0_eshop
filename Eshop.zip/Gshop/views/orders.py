from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.customer import Customers
from Gshop.models.product import Product
from Gshop.models.order import Order
from django.views import View
from Gshop.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator

class OrderList(View):  
   @method_decorator(auth_middleware)
   def get(self,request):
      customer = request.session.get('customer_id')
      orders =Order.get_order_by_id(customer)
      return render(request,'orders.html',{'orders':orders})
