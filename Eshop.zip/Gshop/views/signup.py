from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.product import Product
from Gshop.models.category import Category
from Gshop.models.customer import Customers
from django.views import View
#Create your views here.


class Sighnup(View):
   def get(self,request):
      return render(request, 'signup.html')
   def post(self,request):
      postdata = request.POST
      first_name = postdata.get('Name')
      last_name = postdata.get('LastName')
      phone = postdata.get('phonenumber')
      email = postdata.get('email')
      password = postdata.get('password')
      value = {'first_name': first_name, 'last_name': last_name, 'phone': phone, 'email': email}
      customer = Customers(first_name=first_name, last_name=last_name
                           , phone=phone, email=email, password=password)
      error_msg = self.validatecustomer(customer)
      if not error_msg:
         customer.password = make_password(password)
         customer.register()
         return redirect("homepage")
      else:
         data = {'values': value, 'error_msg': error_msg}
         return render(request, 'signup.html', data)

   def validatecustomer(self,customer):
      error_msg = None
      if len(customer.first_name) < 4:
         error_msg = "name must be more then 4 character"
      elif len(customer.last_name) < 4:
         error_msg = "lastname must be more then 4 character"
      elif len(customer.phone) < 10 or len(customer.phone) > 10:
         error_msg = "phone must be of 10 digit"
      elif not customer.email:
         error_msg = "mail is required"
      elif not customer.password:
         error_msg = "password must be required"
      elif customer.password.find('@') == -1:
         error_msg = "password must contain @ symbol"
      elif customer.Isexist():
         error_msg = "email already exist"
      return error_msg