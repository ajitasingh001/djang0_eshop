from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.customer import Customers
from Gshop.models.product import Product
from django.views import View

class Cart(View):
   def get(self,request):
      ids = list(request.session.get('cart'))
      products = Product.get_product_by_id(ids)
      if products:
         return render(request, 'cart.html',{'products':products})
      else:
         return render(request, 'cart.html')
