from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from .models.product import Product
from .models.category import Category
from .models.customer import Customers
from django.views import View
#Create your views here.

print(make_password('1234'))
print(check_password('1234','pbkdf2_sha256$260000$jTGt0JNYrwPnb1y8BKCMxD$cU8z/sbnSBTkSdMXFPeDepRKAuEwrRwh1Uq+Fktgczs='))
def index(request):
   product = None
   category =Category.get_all_categories()
   categoryid = request.GET.get('category')
   data={}
   if categoryid:
      product = Product.get_all_products_by_categoryid(categoryid)
   else :
      product = Product.get_all_products()

   data['product']=product
   data['category'] = category
   return render(request,'orders/orders.html',data)

# validate your form here


class Sighnup(View):
   def get(self,request):
      return render(request, 'signup.html')
   def post(self,request):
      postdata = request.POST
      first_name = postdata.get('Name')
      last_name = postdata.get('LastName')
      phone = postdata.get('phonenumber')
      email = postdata.get('email')
      password = postdata.get('password')
      value = {'first_name': first_name, 'last_name': last_name, 'phone': phone, 'email': email}
      customer = Customers(first_name=first_name, last_name=last_name
                           , phone=phone, email=email, password=password)
      error_msg = self.validatecustomer(customer)
      if not error_msg:
         customer.password = make_password(password)
         customer.register()
         return redirect("homepage")
      else:
         data = {'values': value, 'error_msg': error_msg}
         return render(request, 'signup.html', data)

   def validatecustomer(self,customer):
      error_msg = None
      if len(customer.first_name) < 4:
         error_msg = "name must be more then 4 character"
      elif len(customer.last_name) < 4:
         error_msg = "lastname must be more then 4 character"
      elif len(customer.phone) < 10 or len(customer.phone) > 10:
         error_msg = "phone must be of 10 digit"
      elif not customer.email:
         error_msg = "mail is required"
      elif not customer.password:
         error_msg = "password must be required"
      elif customer.password.find('@') == -1:
         error_msg = "password must contain @ symbol"
      elif customer.Isexist():
         error_msg = "email already exist"
      return error_msg


class Login(View):
   def get(self,request):
      return render(request, 'login.html')
   def post(self,request):
      error_msg = None
      email = request.POST.get('email')
      password = request.POST.get('password')
      customer = Customers.loginCheck(email)
      if customer:
         flag = check_password(password, customer.password)
         if flag:

            return redirect('homepage')
         else:
            error_msg ="password is incorrect"
      else :
         error_msg = "no mail exist with this mail id please signup first"
      return render(request, 'login.html',{'error_msg':error_msg})
# def validatecustomer(customer):
#    error_msg =None
#    if len(customer.first_name) < 4:
#       error_msg = "name must be more then 4 character"
#    elif len(customer.last_name) < 4:
#       error_msg = "lastname must be more then 4 character"
#    elif len(customer.phone) < 10 or len(customer.phone) > 10:
#       error_msg = "phone must be of 10 digit"
#    elif not customer.email:
#       error_msg = "mail is required"
#    elif not customer.password:
#       error_msg = "password must be required"
#    elif customer.password.find('@') == -1:
#       error_msg = "password must contain @ symbol"
#    elif customer.Isexist():
#       error_msg = "email already exist"
#    return error_msg

# def registeruser(request):
#    postdata = request.POST
#    first_name = postdata.get('Name')
#    last_name = postdata.get('LastName')
#    phone = postdata.get('phonenumber')
#    email = postdata.get('email')
#    password = postdata.get('password')
#    value = {'first_name': first_name, 'last_name': last_name, 'phone': phone, 'email': email}
#    customer = Customers(first_name=first_name, last_name=last_name
#                         , phone=phone, email=email, password=password)
#    error_msg = validatecustomer(customer)
#    if not error_msg:
#       customer.password = make_password(password)
#       customer.register()
#       return redirect("homepage")
#    else:
#       data = {'values': value, 'error_msg': error_msg}
#       return render(request, 'signup.html', data)




# def signup(request):
#    if request.method == "GET":
#       return render(request,'signup.html')
#    else :
#       return registeruser(request)






# def login(request):
#    if request.method == 'GET':
#       return  render(request,'login.html')
#    else:
#       error_msg =None
#       email = request.POST.get('email')
#       password = request.POST.get('password')
#       customer = Customers.loginCheck(email)
#       if customer:
#          flag = check_password(password, customer.password)
#          if flag:
#             return redirect('homepage')
#          else:
#             error_msg ="password is incorrect"
#       else :
#          error_msg = "no mail exist with this mail id please signup first"
#       return render(request, 'login.html',{'error_msg':error_msg})