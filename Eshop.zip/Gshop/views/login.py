from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.customer import Customers
from django.views import View



class Login(View):

   def get(self,request):
      return render(request, 'login.html',{'login':"please login here"})
   def post(self,request):
      error_msg = None
      email = request.POST.get('email')
      password = request.POST.get('password')
      customer = Customers.loginCheck(email)
      if customer:
         flag = check_password(password, customer.password)
         if flag:
            request.session['customer_id'] = customer.id
            request.session['email'] = customer.email
            return redirect('homepage')
         else:
            error_msg ="password is incorrect"
      else :
         error_msg = "no mail exist with this mail id please signup first"
      return render(request, 'login.html',{'error_msg':error_msg})


# logout function
def logout(request):
   request.session.clear()
   return redirect('login')
