from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password,check_password
from django.http import HttpResponse
from Gshop.models.customer import Customers
from Gshop.models.product import Product
from Gshop.models.order import Order
from django.views import View

class CheckOut(View):
   def post(self,request):
      address = request.POST.get('address')
      Phone = request.POST.get('phone')
      customer =request.session.get('customer_id')
      print('custoer..........................',customer)
      cart = request.session.get('cart')
      products =Product.get_product_by_id(list(cart.keys()))
      print(address,Phone,customer,cart,products)
      if customer:
         for product in products:
            order =Order(product=product,customer=Customers(id=customer),quantity=cart.get(str(product.id))
                         ,price=product.price,address=address,Phone=Phone)
            order.palce_order()
            request.session['cart']={}
         return redirect('cart')
      else:
         return redirect('login')
