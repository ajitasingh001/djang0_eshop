from django.contrib import admin

# Register your models here.
from Gshop.models.product import Product
from Gshop.models import category
from Gshop.models import customer,order



class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','price','category','description']

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']

class CustomerAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone', 'email','password']

class OrderAdmin(admin.ModelAdmin):
    list_display = ['product', 'customer', 'quantity', 'price','address','Phone','date']

admin.site.register(Product,ProductAdmin)
admin.site.register(category.Category,CategoryAdmin)
admin.site.register(customer.Customers,CustomerAdmin)
admin.site.register(order.Order,OrderAdmin)